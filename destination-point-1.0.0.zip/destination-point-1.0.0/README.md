## Destination point app
#
## Stack
- Flutter
- Firebase
  
```
git clone https://github.com/Mugamba669/destination-point.git
```
## Get started

### Then run
``` 
flutter pub get
```