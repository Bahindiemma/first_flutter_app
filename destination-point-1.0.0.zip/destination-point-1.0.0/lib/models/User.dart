class AUser {
  String? name;
  String email;
  String password;

  AUser({required this.email, this.name, required this.password});
}
